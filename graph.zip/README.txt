Matlab file for conversion of the txt results from OpenDS distraction update logging.
To create PDF of the distraction task results, use command:

log_pdf('Path/to/your/data','path/to/the/created/PDF')

